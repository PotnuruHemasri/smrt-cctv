# smart-cctv-tkinter
This is a tkinter gui app for smart camera.
you just need to run main.py file inorder to run full app 
you would need :
opencv
tkinter
installed to run these scripts properly
thanks :) 

